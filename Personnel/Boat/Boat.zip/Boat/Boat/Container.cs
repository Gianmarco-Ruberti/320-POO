﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExoBoat
{
    public class Container
    {
        private string _tag;

        public Container(string tag)
        {
            _tag = tag;
        }

        public override string ToString()
        {
            return $"Container {_tag}";
        }
    }
}
