﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExoBoat
{
    public class RefrigeratedContainer : Container
    {
        private int _temperature;

        public RefrigeratedContainer(string tag, int temp) : base(tag)
        {
            _temperature = temp;
        }

        public override string ToString()
        {
            return $"{base.ToString()}, température: {_temperature}";
        }
    }
}
