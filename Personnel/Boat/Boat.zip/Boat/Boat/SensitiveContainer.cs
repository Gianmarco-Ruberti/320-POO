﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExoBoat
{
    public class SensitiveContainer: Container
    {
        private string _content;

        public SensitiveContainer(string tag, string content) : base(tag)
        {
            _content = content;
        }

        public override string ToString()
        {
            return $"{base.ToString()}, contient: {_content}";
        }

    }
}
