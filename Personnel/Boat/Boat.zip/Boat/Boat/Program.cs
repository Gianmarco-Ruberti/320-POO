﻿using ExoBoat;

Boat boat = new Boat(22, "Lamoco Cadix", "Tanker");

boat.Containers.Add(new RefrigeratedContainer("x21", 12));
boat.Containers.Add(new RefrigeratedContainer("w451", 12));
boat.Containers.Add(new RefrigeratedContainer("Op44", 12));
boat.Containers.Add(new SensitiveContainer("21re", "Acid"));
boat.Containers.Add(new SensitiveContainer("ggh1", "Petrol"));

Console.WriteLine(boat);
boat.PrintLoad();

Console.ReadKey();

