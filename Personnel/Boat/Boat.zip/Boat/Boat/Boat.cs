﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExoBoat
{
    public class Boat
    {
        private int _id;
        private string _name;
        private string _description;

        private List<Container> _containers;
        public List<Container> Containers { get => _containers; }

        public Boat(int id, string name, string description)
        {
            _id = id;
            _name = name;
            _description = description;
            _containers = new List<Container>();
        }


        public void PrintLoad()
        {
            foreach (Container container in Containers)
            {
                Console.WriteLine(container);
            }
        }

        public override string ToString()
        {
            return $"Le bateau {_id} s'appelle {_name}, c'est un {_description}";
        }
    }
}
